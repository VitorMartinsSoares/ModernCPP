#include <iostream>
#include <string>
#include "url.h"
using namespace std;

int main(){
    Url novo = R"(https://www.cefetmg.br:443/)"_url;
    cout << novo.getDominio() << endl;
    return 0;
}